/* XPM */
/* $XConsortium: NoBackdrop.pm /main/3 1995/07/18 17:19:11 drk $ */
/*************************************************************************/
/**  (c) Copyright 1993, 1994 Hewlett-Packard Company			**/
/**  (c) Copyright 1993, 1994 International Business Machines Corp.	**/
/**  (c) Copyright 1993, 1994 Sun Microsystems, Inc.			**/
/**  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary	**/
/**      of Novell, Inc.						**/
/*************************************************************************/
static char * noBackdrop [] = {
/* width height ncolors cpp [x_hot y_hot] */
"2 2 1 1 -1 -1",
/* colors */
" 	s iconColor1	m black	c black",
/* pixels */
"  ",
"  "};
